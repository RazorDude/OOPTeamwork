﻿namespace Data.Items.Obtacles
{
    class Obtacle : Item
    {
        public Obtacle()
        {
           // this.IsObtacle = true;
        }
    }
}
