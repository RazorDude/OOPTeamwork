﻿using System;

namespace Data.Items.Potions
{
    public interface IConsumable
    {
        void Consume();
    }
}
