﻿public enum Direction
{
    Left = 1, Right = 2, Up = 3, Down = 4
}

