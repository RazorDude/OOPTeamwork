﻿using System;

namespace Data.Items
{
    public interface IWearable
    {

    }
}