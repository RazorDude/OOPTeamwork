﻿
namespace Data.Items.Potions
{
    public class StrengthPotion : Potion
    {
        public StrengthPotion(decimal weight, int bonus)
            : base(weight, bonus)
        {

        }
    }
}
