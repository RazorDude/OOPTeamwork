﻿using System;
namespace Data.Items.Potions
{
    public class HealthPotion : Potion
    {
        public HealthPotion(decimal weight, int bonus)
            : base(weight, bonus)
        {

        }
    }
}
