﻿using System;

namespace Data.Items.Potions
{
    public class ManaPotion : Potion
    {
        public ManaPotion(decimal weight, int bonus)
            : base(weight, bonus)
        {

        }
    }
}
