﻿using System;

namespace Data.Items.Potions
{
    public interface IConsumable
    {
        int Consume();
    }
}
