﻿using System;

namespace Data.Items.Weapons
{
    interface IDamageDealable
    {
        int DealDamage();
    }
}
