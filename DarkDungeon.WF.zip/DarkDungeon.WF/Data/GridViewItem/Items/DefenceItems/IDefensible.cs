﻿using System;

namespace Data.Items.DefenceItems
{
    public interface IDefensible
    {
        int AbsorbDamage(int damage);
    }
}
