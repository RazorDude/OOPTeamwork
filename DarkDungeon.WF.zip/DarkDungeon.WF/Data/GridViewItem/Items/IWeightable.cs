﻿using System;

namespace Data.Items
{
    public interface IWeightable
    {
        decimal GetWeight();
    }
}
