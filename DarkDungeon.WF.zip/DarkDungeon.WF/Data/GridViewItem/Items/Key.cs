﻿namespace Data.Items
{
    public class Key : Item
    {
        public Key() : base() { }
    }
}
